import fs from 'node:fs';
import path from 'node:path';
import assert from 'node:assert/strict';
import {fileURLToPath} from 'node:url';
import {build} from 'esbuild';
import {chromium} from 'playwright';
import {unzipSync,strFromU8} from 'fflate';
const R=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..');
const bundled=await build({stdin:{contents:"import * as bridge from './src/download_bridge.mjs';import * as xlsx from './src/xlsx.mjs';import * as core from './src/core.mjs';import {setMarkup} from './src/dom.mjs';import {Visual} from './src/visual.mjs';import {inflateSync} from 'fflate';globalThis.testAPI={...bridge,...xlsx,...core,setMarkup,Visual,inflateSync};",resolveDir:R},bundle:true,write:false,format:'iife',loader:{'.css':'text','.svg':'text'}});
console.log('Launching headless Edge');
const browser=await chromium.launch({headless:true,...(process.env.NF_TEST_BROWSER?{executablePath:process.env.NF_TEST_BROWSER}:process.platform==='win32'?{channel:'msedge'}:{}),timeout:30000});
const checks=[],artifacts=path.join(R,'test-output');fs.mkdirSync(artifacts,{recursive:true});
const page=await browser.newPage({viewport:{width:1360,height:850}});
page.on('pageerror',e=>checks.push({name:'unexpected-page-error',pass:false,error:e.message}));
try{
 await page.setContent('<!doctype html><html><body><div id="visual"></div><button id="copy" style="position:fixed;top:770px;left:20px;z-index:99999">copy</button><button id="launch" style="position:fixed;top:770px;left:120px;z-index:99999">launch</button></body></html>');
 await page.addScriptTag({content:bundled.outputFiles[0].text});
 async function test(name,fn,arg){console.log('RUN',name);const result=await page.evaluate(fn,arg);assert.equal(result.pass,true,name+': '+JSON.stringify(result));checks.push({name,...result});}
 await test('DOM contexts, SVG namespace, constructor CSS and table/select data',()=>{
  const a=testAPI,host={};globalThis.visual=new a.Visual({host,element:document.querySelector('#visual')});
  const tb=document.createElement('tbody');a.setMarkup(tb,'<tr><td>0012</td><td>0</td></tr>');
  const tr=document.createElement('tr');a.setMarkup(tr,'<td>x</td>');const select=document.createElement('select');a.setMarkup(select,'<option value="2" selected>2</option>');
  const root=visual.root;return {pass:tb.rows.length===1&&tr.cells.length===1&&select.value==='2'&&root.querySelector('svg')?.namespaceURI==='http://www.w3.org/2000/svg'&&getComputedStyle(root).position==='absolute'&&document.querySelector('#visual style')?.textContent.length>100,position:getComputedStyle(root).position};
 });
 await test('page-only for every native status including Allowed; zero native property/status/download calls',async()=>{
  const a=testAPI,payload=a.createTablePayload({origin:'Vendido',fields:[]},[],[{name:'Tabela',headers:['Código','Valor'],numeric:[false,true],rows:[['0001',1234.56],['0002',0],['0003',-2.5]]}]);
  const bytes=a.makeXlsx(payload.S),results=[];let propertyReads=0,statusCalls=0,nativeCalls=0;
  for(const status of [0,1,2,3,undefined]){let opened=0;const h={get downloadService(){propertyReads++;return {exportStatus:async()=>{statusCalls++;return status;},exportVisualsContentExtended:async()=>{nativeCalls++;}};},webAccessService:{webAccessStatus:async()=>0},launchUrl:()=>opened++};const plan=await a.prepareDownloadPlan(h,bytes,'x.xlsx',{payload,rows:3});results.push(plan.transport);if(opened)throw Error('automatic launch');}
  globalThis.smallPayload=payload;return {pass:results.every(x=>x==='fragment')&&propertyReads===0&&statusCalls===0&&nativeCalls===0,results,propertyReads,statusCalls,nativeCalls};
 });
 await test('WebAccess denial blocks page even if native would be Allowed',async()=>{
  const a=testAPI;let touched=0,opened=0,denied=false;const h={get downloadService(){touched++;throw Error('native touched');},webAccessService:{webAccessStatus:async()=>3},launchUrl:()=>opened++};
  try{await a.prepareDownloadPlan(h,a.makeXlsx(smallPayload.S),'x.xlsx',{payload:smallPayload});}catch(e){denied=/acesso/.test(e.message);}
  return {pass:denied&&touched===0&&opened===0,denied,nativePropertyReads:touched};
 });
 await test('small fragment exact typed data and metadata; no query business payload',async()=>{
  const a=testAPI,h={webAccessService:{webAccessStatus:async()=>0}},cfg={title:'Vendido 2026',origin:'Vendido',fields:[{label:'Vendedor',table:'d_Vendedor',column:'Código',values:[{value:'01',label:'Equipe A'}]}]},filters=[a.basic('d_Vendedor','Código',['01']),a.basic('d_HTML_Pagina_Pedidos','Pagina',[2]),a.dateFilter({table:'d_Data',column:'Data'},'2026-01-01','2026-11-26')];
  const payload=a.createTablePayload(cfg,filters,smallPayload.S.filter(s=>s.name!=='Contexto'),'Período aplicado — Data Entrada: 01/01/2026–26/11/2026'),plan=await a.prepareDownloadPlan(h,a.makeXlsx(payload.S),'teste.xlsx',{payload,rows:3}),u=new URL(plan.url),p=new URLSearchParams(u.hash.slice(1));
  const decoded=JSON.parse(new TextDecoder().decode(a.inflateSync(Uint8Array.from(atob(p.get('j').replaceAll('-','+').replaceAll('_','/')),c=>c.charCodeAt(0)))));
  globalThis.smallPlan=plan;globalThis.host=h;return {pass:u.search===''&&p.get('v')==='2'&&p.get('c')==='1'&&plan.url.length<=2500&&decoded.S[0].rows[0][0]==='0001'&&decoded.S[0].rows[0][1]===1234.56&&decoded.S[0].rows[1][1]===0&&decoded.filtros.length===2&&!JSON.stringify(decoded).includes('d_HTML_Pagina')&&decoded.periodos.includes('26/11/2026')&&decoded.filtros[0].valor==='Equipe A'};
 });
 await test('synthetic click cannot launch; preparation cannot launch',async()=>{
  let opened=0;const h={webAccessService:{webAccessStatus:async()=>0},launchUrl:()=>opened++};let refused=false;try{await testAPI.launchDownloadPlan(h,smallPlan,new MouseEvent('click'));}catch{refused=true;}return {pass:refused&&opened===0};
 });
 await page.evaluate(()=>{globalThis.opened=[];document.querySelector('#launch').onclick=e=>testAPI.launchDownloadPlan({...host,launchUrl:u=>opened.push(u)},smallPlan,e).then(()=>globalThis.launchOK=true).catch(e=>globalThis.launchError=e.message);});
 await page.click('#launch');await page.waitForFunction(()=>globalThis.launchOK||globalThis.launchError);assert.equal(await page.evaluate(()=>opened.length),1);checks.push({name:'fresh trusted click launches fragment',pass:true});
 await test('large NFPT1 payload includes every row and precise types',async()=>{
  const rows=Array.from({length:5001},(_,i)=>[String(i).padStart(8,'0'),Math.sin(i)*12345,i%3===0?0:-i/100,'Descrição '+i+' '+Math.cos(i)]),payload=testAPI.createTablePayload({origin:'Em Aberto',fields:[]},[],[{name:'Materiais',headers:['Código','Valor','Negativo','Descrição'],numeric:[false,true,true,false],rows}]);
  const bytes=testAPI.makeXlsx(payload.S);globalThis.largePlan=await testAPI.prepareDownloadPlan(host,bytes,'grande.xlsx',{payload,rows:5001});
  const text=largePlan.clipboardText;const decoded=JSON.parse(new TextDecoder().decode(testAPI.inflateSync(Uint8Array.from(atob(text.slice(6).replaceAll('-','+').replaceAll('_','/')),c=>c.charCodeAt(0)))));
  return {pass:largePlan.transport==='clipboard'&&text.startsWith('NFPT1.')&&largePlan.url.length<=2500&&decoded.S[0].rows.length===5001&&decoded.S[0].rows[0][0]==='00000000'&&decoded.S[0].rows[1][1]===rows[1][1]&&decoded.S[0].rows[0][2]===0,rows:decoded.S[0].rows.length};
 });
 await test('large cannot launch before copying or after context changed',async()=>{
  let ok=0;for(const options of [{},{isCurrent:()=>false}])try{await testAPI.launchDownloadPlan({...host,launchUrl:()=>{throw Error('launched');}},largePlan,{type:'click',isTrusted:true},options);}catch(e){if(/Copie|recorte/.test(e.message))ok++;}return {pass:ok===2};
 });
 await page.evaluate(()=>{globalThis.copyAttempts=0;globalThis.copyResult=null;document.querySelector('#copy').onclick=e=>testAPI.copyPlanPayload(host,largePlan,e,{clipboard:{writeText:async text=>{copyAttempts++;if(copyAttempts===1)throw Error('denied');globalThis.clipText=text;}}}).then(()=>copyResult='ok').catch(e=>copyResult=e.message);});
 await page.click('#copy');await page.waitForFunction(()=>copyResult!==null);assert.match(await page.evaluate(()=>copyResult),/Clique novamente/);
 await page.evaluate(()=>copyResult=null);await page.click('#copy');await page.waitForFunction(()=>copyResult==='ok');checks.push({name:'clipboard denied useful error and fresh-click retry',pass:true});
 await page.evaluate(()=>{launchOK=false;launchError=null;document.querySelector('#launch').onclick=e=>testAPI.launchDownloadPlan({...host,launchUrl:u=>opened.push(u)},largePlan,e).then(()=>launchOK=true).catch(e=>launchError=e.message);});
 await page.click('#launch');await page.waitForFunction(()=>launchOK||launchError);assert.equal(await page.evaluate(()=>new URLSearchParams(new URL(opened.at(-1)).hash.slice(1)).get('k')),'cola');checks.push({name:'fresh click opens short clipboard URL after confirmed copy',pass:true});
 await test('invalid URL, malformed numeric/rows, unsupported payload, over-limit all rejected',async()=>{
  const a=testAPI,fail=[];for(const u of ['http://a.github.io/','https://github.io.evil.test/','javascript:alert(1)','https://a.github.io@evil.test/'])try{a.validateDownloadPage(u);}catch{fail.push(u);}
  for(const rows of [[['x']],[['x','invalid']]])try{a.normalizeSheets([{name:'A',headers:['c','n'],numeric:[false,true],rows}]);}catch{fail.push('row');}
  try{await a.prepareDownloadPlan(host,new Uint8Array(31*1024*1024),'x.xlsx',{payload:smallPayload});}catch{fail.push('big');}
  try{await a.prepareDownloadPlan(host,a.makeXlsx(smallPayload.S),'x.xlsx',{payload:{tipo:'other'}});}catch{fail.push('payload');}
  return {pass:fail.length===8,rejections:fail.length};
 });
 await test('fingerprint keeps dates/commercial selections and ignores only technical pages',()=>{
  const a=testAPI,c={origin:'Vendido',view:'Pedidos',count:3,pages:1,headers:['A']},x=[a.basic('d_X','UF',['SP'])],p=a.basic('d_HTML_Pagina_Pedidos','Pagina',[2]);
  return {pass:a.exportFingerprint(c,x)===a.exportFingerprint(c,[...x,p])&&a.exportFingerprint(c,x)!==a.exportFingerprint(c,[a.basic('d_X','UF',['RJ'])])&&a.exportFingerprint(c,x)!==a.exportFingerprint(c,[...x,a.dateFilter({table:'d_Data',column:'Data'},'2026-01-01','2026-02-01')])};
 });
 // Exercise the actual Visual.export collector, leaving its context/count checks intact.
 await page.evaluate(()=>{globalThis.setupVisual=(mode='ok',nativeAllowed=true)=>{
  visual.destroy();globalThis.nativePropertyReads=0;globalThis.nativeStatusCalls=0;visual=new testAPI.Visual({element:document.querySelector('#visual'),host:{get downloadService(){nativePropertyReads++;return {exportStatus:async()=>{nativeStatusCalls++;return nativeAllowed?0:3;},exportVisualsContentExtended:async(...a)=>{globalThis.nativeCalls.push(a);return {downloadCompleted:true};}};},webAccessService:{webAccessStatus:async()=>0},launchUrl:u=>opened.push(u)}});
  globalThis.nativeCalls=[];globalThis.restored=[];const count=501,c={origin:'Vendido',title:'Vendido',view:'Pedidos',count,pages:2,page:2,revision:'test',headers:['Pedido','Valor'],numericColumns:[false,true],widths:[150,180],fields:[],showViews:true};visual.config=c;visual.footer='<span><b>Vendido</b> 1.234,56</span>';visual.filters=[];visual.exportSettings={production:true,pageURL:testAPI.DOWNLOAD_PAGE};visual.body='<tr><td>00000501</td><td class="num">0,00</td></tr>';visual.render();visual.overlay.hidden=false;
  visual.applyPage=(p)=>restored.push(p);
  visual.requestPage=async p=>{visual.job.touchedPages=true;visual.config.page=p;if(mode==='cancel')visual.job.cancelled=true;let n=p===1?500:1;if(mode==='incomplete'&&p===1)n--;const body=Array.from({length:n},(_,i)=>'<tr><td>'+String(i+(p===1?1:501)).padStart(8,'0')+'</td><td class="num">'+(i===0?'1.234,56':'0,00')+'</td></tr>').join('');return {config:visual.config,body,fingerprint:mode==='changed'?'different':visual.currentExportFingerprint()};};
 };});
 for(const mode of ['ok','incomplete','changed','cancel']){
  const result=await page.evaluate(async mode=>{setupVisual(mode);await visual.export(true);return {calls:nativeCalls.length,statusCalls:nativeStatusCalls,propertyReads:nativePropertyReads,prepared:!!visual.downloadPlan,restored,dialog:visual.overlay.textContent};},mode);
  assert.equal(result.calls,0,mode);assert.equal(result.statusCalls,0,mode);assert.equal(result.propertyReads,0,mode);assert.equal(result.prepared,mode==='ok',mode);assert.deepEqual(result.restored,[2],mode+' restoration');checks.push({name:'actual collector '+mode+' and restore original page',pass:true});
 }
 await test('actual Visual Allowed + production=false still prepares page with every row and Contexto',async()=>{setupVisual('ok');visual.exportSettings.production=false;const before=opened.length;await visual.export(true);
  const plan=visual.downloadPlan,data=plan.transport==='clipboard'?plan.clipboardText.slice(6):new URLSearchParams(new URL(plan.url).hash.slice(1)).get('j');
  const actual=JSON.parse(new TextDecoder().decode(testAPI.inflateSync(Uint8Array.from(atob(data.replaceAll('-','+').replaceAll('_','/')),c=>c.charCodeAt(0)))));
  const rows=[...Array.from({length:500},(_,i)=>[String(i+1).padStart(8,'0'),i===0?'1.234,56':'0,00']),['00000501','1.234,56']];
  const expected=testAPI.createTablePayload(visual.config,[],[{name:'Pedidos',headers:['Pedido','Valor'],numeric:[false,true],rows,title:'Relatório de Pedidos — Vendido | Pedidos'},{name:'Totais do filtro',headers:['Indicador','Valor'],numeric:[false,true],rows:[['Vendido','1.234,56']],title:'Relatório de Pedidos — Vendido | Totais do filtro'}],visual.root.querySelector('.nf-intro').textContent);
  globalThis.integrationPayload=actual;globalThis.referenceBytes=Array.from(testAPI.makeXlsx(actual.S));
  return {pass:nativeCalls.length===0&&nativeStatusCalls===0&&nativePropertyReads===0&&opened.length===before&&plan.exportMode==='githubPages'&&JSON.stringify(actual)===JSON.stringify(expected),nativeCalls:nativeCalls.length,nativeStatusCalls,nativePropertyReads,rows:actual.S[0].rows.length};});
 await test('actual Visual unavailable-native also prepares page without auto launch',async()=>{setupVisual('ok',false);const n=opened.length;await visual.export(true);return {pass:nativeCalls.length===0&&nativeStatusCalls===0&&nativePropertyReads===0&&visual.downloadPlan?.rows===501&&visual.downloadPlan?.exportMode==='githubPages'&&opened.length===n,transport:visual.downloadPlan?.transport};});
 await page.screenshot({path:path.join(artifacts,'visual_exportacao.png'),fullPage:true});
 const reference=Uint8Array.from(await page.evaluate(()=>referenceBytes));fs.writeFileSync(path.join(artifacts,'reference_501.xlsx'),reference);
 fs.writeFileSync(path.join(artifacts,'payload_501.json'),JSON.stringify(await page.evaluate(()=>integrationPayload),null,2));
 const parts=unzipSync(reference);const workbook=strFromU8(parts['xl/workbook.xml']),sheet=strFromU8(parts['xl/worksheets/sheet1.xml']);assert.match(workbook,/Contexto/);assert.ok(sheet.includes('<v>1234.56</v>'));assert.ok(!sheet.includes('<v>123456</v>'));checks.push({name:'reference workbook Contexto and actual typed precision',pass:true});
 const src=fs.readdirSync(path.join(R,'src')).filter(x=>x.endsWith('.mjs')).map(x=>fs.readFileSync(path.join(R,'src',x),'utf8')).join('\n');assert.equal(src.includes('.innerHTML'),false);assert.equal(src.includes('downloadService'),false);assert.equal(src.includes('exportStatus'),false);assert.equal(src.includes('exportVisualsContent'),false);assert.doesNotMatch(src,/<form\b|submit\s*=/i);checks.push({name:'no native download API or innerHTML/form/submit in source',pass:true});
 await page.clock.install();
 await page.evaluate(()=>visual.status('Arquivo pronto.'));
 await page.clock.fastForward(6000);assert.equal(await page.locator('.nf-status').evaluate(n=>n.style.opacity),'0');
 await page.clock.fastForward(250);assert.equal(await page.locator('.nf-status').textContent(),'');
 await page.evaluate(()=>visual.status('Erro: tente novamente.',true));await page.clock.fastForward(6000);assert.equal(await page.locator('.nf-status').evaluate(n=>n.style.opacity),'1');
 await page.clock.fastForward(4000);assert.equal(await page.locator('.nf-status').evaluate(n=>n.style.opacity),'0');
 await page.evaluate(()=>visual.status('Carregando opções completas de filtro…'));await page.clock.fastForward(20000);assert.match(await page.locator('.nf-status').textContent(),/Carregando/);
 checks.push({name:'status fades 6s success / 10s error; ongoing loading preserved',pass:true});
 assert.equal(checks.every(c=>c.pass),true);
 fs.writeFileSync(path.join(R,'testes_prompt.json'),JSON.stringify({pass:true,environment:'Playwright Edge headless fake Power BI host; synthetic data only',checks,limitations:['No real Embedded/Service tenant execution; publication and PBIX integration remain ROOT.','Receiver end-to-end workbook parity is validated by receiver executor.']},null,2));
 console.log('PASS',checks.length,'checks');
}catch(e){fs.writeFileSync(path.join(R,'testes_prompt.json'),JSON.stringify({pass:false,checks,error:e.stack},null,2));throw e;}
finally{await browser.close();}
