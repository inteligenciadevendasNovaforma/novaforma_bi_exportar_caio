# Relatório de Pedidos — exportação pela página

Visual existente Novaforma, GUID preservado `novaformaPedidosHTMLA41E65D7C9B64E03A822510202600101`, versão `1.0.0.2`, API Power BI `5.11.0`. Fonte portátil, sem dados comerciais, PBIX ou modelo semântico.

## Compilar e testar

Com Node.js 18+ e npm:

```sh
npm ci
npm run build
npm test
```

Dependências fixas em `package-lock.json`: esbuild, fflate e Playwright. O teste usa Edge instalado no Windows; em outros sistemas, instale Chromium com `npx playwright install chromium`. Opcionalmente informe o executável com `NF_TEST_BROWSER`. O build não depende de Power BI Desktop nem de caminhos deste workspace. A variável opcional `NF_BUILD_DEPENDENCIES` continua disponível para ambientes que já têm esbuild/fflate instalados.

O build gera `dist/resource.json`, `.pbiviz`, manifestos e preview. Não altere o GUID ao substituir o recurso no relatório existente. As licenças de terceiros estão em `licenses/`.

## Comportamento

O visual coleta e confere todo o recorte, preservando o coletor, contagem, paginação, fingerprint, cancelamento e restauração condicionada da página original. Cabeçalhos, grão, filtros e cálculos financeiros continuam vindos do modelo. Mudanças no contexto invalidam a preparação; não é emitido arquivo parcial.

1. Por determinação expressa de 27/11/2026, o botão sempre retorna a página configurada. Não consulta nem chama DownloadService, mesmo quando o host permitiria download direto.
2. Verifica somente WebAccess para essa página. WebAccess recusado bloqueia a abertura/cópia.
3. A carga JSON UTF-8 é comprimida com deflate-raw e base64url. Até o limite preventivo do link, usa `#v=2&n=…&c=1&j=…`. Acima dele, oferece **Copiar dados → Abrir página de download → Colar dados**, prefixo `NFPT1.` e URL curta `#k=cola`. Cada cópia/abertura exige clique explícito; atualizações do visual não abrem páginas.

**Formatar → Exportação → Endereço da página de download** configura `export.pageURL`. Padrão:
`https://inteligenciadevendasnovaforma.github.io/novaforma_bi_exportar_caio/download-page/`

Somente HTTPS em subdomínio `github.io`, sem credenciais/porta, é aceito. O capabilities declara `WebAccess` para `https://*.github.io`. As propriedades legadas `production` e `pagesClipboardReady` permanecem no schema para compatibilidade com PBIX existentes; não alteram a regra de página exclusiva, inclusive quando production=false. ExportContent foi removido dos privilégios, pois o botão não usa download direto.

## Contrato da página

O receptor deve aceitar JSON `tipo:"pedidosTabela",versao:1,titulo,periodos,filtros,S`. Cada elemento de `S` contém `name,headers,rows,numeric,title?`. Colunas numéricas são números reais ou null, incluindo zero/negativos; códigos e demais textos permanecem strings. A mesma coleção `S` gera o XLSX de referência local e o da página, incluindo a aba **Contexto** com título, período realmente exibido no início e filtros legíveis. Somente os dois seletores técnicos de página ficam fora da descrição de filtros.

A página deve suportar `pedidosTabela` em `#j` e `NFPT1.` em clipboard antes da integração do visual. A versão anterior do site não entende esse contrato; publicar somente o visual não basta para a rota externa. O pacote da página é entregue pela frente responsável, preservando os prefixos legados. O arquivo e JSON têm limite de 30 MiB; links completos respeitam o limite preventivo de 2.500 caracteres, sem cortar linhas.

## Validação e limites

`npm test` executa Playwright com host Power BI simulado e dados sintéticos. Verifica página exclusiva e zero acessos a APIs nativas, permissões, clique real, payload pequeno/grande, precisão e tipos, metadados, cancelamento/contagem/contexto/restauração, DOMParser com tabela/select/SVG/CSS e mensagens transitórias. `testes_prompt.json` registra os resultados; artefatos locais ficam em `test-output/` e não precisam ser publicados.

Este build não altera DAX, modelo, filtros financeiros, navegação ou layout. Não contém `innerHTML`, form ou submit no código do visual. Testes locais não comprovam Power BI Service/Embedded: publicação do receptor, integração no PBIX, save/reopen e teste no host real são etapas separadas a cargo da integração autorizada.
