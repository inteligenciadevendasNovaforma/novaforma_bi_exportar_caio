import {deflateSync} from 'fflate';
import {numberBR} from './xlsx.mjs';
import {analysisPeriodText} from './period.mjs';
import {targetMatches} from './core.mjs';
export const EXPORT_MODES=Object.freeze({production:'githubPages'});
export const DOWNLOAD_PAGE='https://inteligenciadevendasnovaforma.github.io/novaforma_bi_exportar_caio/download-page/';
export const MAX_XLSX_BYTES=30*1024*1024,MAX_URL_LENGTH=2500,XLSX_CLIPBOARD_PREFIX='NFPT1.';
export const XLSX_MIME='application/vnd.openxmlformats-officedocument.spreadsheetml.sheet';
const copiedPlans=new WeakSet();
const canonical=v=>Array.isArray(v)?v.map(canonical).sort((a,b)=>JSON.stringify(a).localeCompare(JSON.stringify(b))):v&&typeof v==='object'?Object.fromEntries(Object.keys(v).sort().map(k=>[k,canonical(v[k])])):v;
export const isTechnicalPage=f=>f?.target?.column==='Pagina'&&['d_HTML_Pagina_Pedidos','d_HTML_Pagina_Materiais'].includes(f.target.table);
export function exportFingerprint(c,filters,totals=[]){return JSON.stringify([c.origin,c.view,c.count,c.pages,c.revision,c.headers,c.numericColumns??null,c.analysisPeriods??null,canonical((filters||[]).filter(f=>!isTechnicalPage(f))),totals]);}
const checkCurrent=fn=>{if(fn&&!fn())throw Error('O recorte mudou. Prepare o arquivo novamente.');};
const encoded=bytes=>{let s='';for(let i=0;i<bytes.length;i+=32768)s+=String.fromCharCode(...bytes.subarray(i,i+32768));return btoa(s);};
const b64url=bytes=>encoded(bytes).replaceAll('+','-').replaceAll('/','_').replace(/=+$/,'');
const fileName=v=>{const s=String(v||'Novaforma_pedidos.xlsx').replace(/[\x00-\x1f\\/:*?"<>|]/g,'_').slice(0,180);return /\.xlsx$/i.test(s)?s:s+'.xlsx';};
const needClick=e=>{if(e?.type!=='click'||e?.isTrusted!==true||globalThis.navigator?.userActivation?.isActive===false)throw Error('Use o botão do relatório para continuar a exportação.');};
export function validateDownloadPage(value=DOWNLOAD_PAGE){
 let u;try{u=new URL(value);}catch{throw Error('Configure um endereço HTTPS válido para a página de download.');}
 if(u.protocol!=='https:'||!u.hostname.endsWith('.github.io')||u.username||u.password||u.port)throw Error('Use uma página HTTPS hospedada em github.io.');
 u.hash='';u.search='';return u.href;
}
// User rule 2026-11-27: page only, independent of every native download API.
export async function assertExportPermissions(host,mode=EXPORT_MODES.production,page=DOWNLOAD_PAGE){
 if(mode!==EXPORT_MODES.production)throw Error('A exportação usa a página configurada.');
 if(typeof host?.webAccessService?.webAccessStatus!=='function'||await host.webAccessService.webAccessStatus(validateDownloadPage(page))!==0)throw Error('O acesso à página de download não está permitido pelo Power BI.');
 return EXPORT_MODES.production;
}
const display=v=>v==null?'(Em branco)':typeof v==='object'?JSON.stringify(v):String(v);
export function readableFilters(config,filters=[]){return filters.filter(f=>!isTechnicalPage(f)).map(f=>{
 const field=(config.fields||[]).find(x=>targetMatches(f,x)),label=field?.label||f.target?.column||'Filtro';
 let value;if(Array.isArray(f.values))value=f.values.map(v=>display((field?.values||[]).find(x=>x.value===v)?.label??v)).join(', ');
 else if(Array.isArray(f.conditions))value=f.conditions.map(c=>({GreaterThanOrEqual:'Desde',LessThanOrEqual:'Até',GreaterThan:'Após',LessThan:'Antes',Is:'Igual a',IsNot:'Diferente de'}[c.operator]||c.operator)+' '+display(c.value)).join(f.logicalOperator==='Or'?' ou ':' e ');
 else value='Seleção ativa';
 return {campo:label,valor:(f.operator==='NotIn'?'Exceto: ':'')+value};
 }).filter((x,i,a)=>a.findIndex(y=>y.campo===x.campo&&y.valor===x.valor)===i);}
export function normalizeSheets(sheets){
 if(!Array.isArray(sheets)||!sheets.length)throw Error('Não há tabelas para exportar.');
 return sheets.map(s=>{
 if(!Array.isArray(s.headers)||!Array.isArray(s.numeric)||s.headers.length!==s.numeric.length||!Array.isArray(s.rows))throw Error('A tabela preparada contém colunas inválidas.');
 return {name:String(s.name),headers:s.headers.map(String),numeric:s.numeric.map(Boolean),...(s.title?{title:String(s.title)}:{}),rows:s.rows.map(row=>{
 if(!Array.isArray(row)||row.length!==s.headers.length)throw Error('A tabela preparada contém uma linha incompleta.');
 return row.map((v,i)=>{if(!s.numeric[i])return String(v??'');const n=numberBR(v);if(n===null&&v!=null&&String(v).trim()&&!['—','–'].includes(String(v).trim()))throw Error('Um valor numérico da tabela não foi reconhecido.');return n;});
 })};
 });
}
export function createTablePayload(config,filters,sheets,capturedPeriod){
 const titulo='Relatório de Pedidos — '+(config.title||config.origin||''),periodos=capturedPeriod??analysisPeriodText(config,filters),filtros=readableFilters(config,filters),S=normalizeSheets(sheets);
 if(!S.some(s=>s.name==='Contexto'))S.push({name:'Contexto',headers:['Campo','Valor'],numeric:[false,false],rows:[['Título',titulo],['Período',periodos],...filtros.map(x=>[x.campo,x.valor])]});
 return {tipo:'pedidosTabela',versao:1,titulo,periodos,filtros,S};
}
export async function prepareDownloadPlan(host,bytes,name,{exportMode=EXPORT_MODES.production,rows=0,pageURL=DOWNLOAD_PAGE,payload}={}){
 exportMode=await assertExportPermissions(host,exportMode,pageURL);
 if(!(bytes instanceof Uint8Array)||bytes.length<4||bytes[0]!==80||bytes[1]!==75||bytes[2]!==3||bytes[3]!==4)throw Error('O arquivo Excel preparado não é válido.');
 if(bytes.length>MAX_XLSX_BYTES)throw Error('O arquivo é grande demais. Nenhum arquivo parcial será enviado.');
 if(!Number.isSafeInteger(rows)||rows<0)throw Error('A contagem de linhas para exportação é inválida.');
 const filename=fileName(name),base={exportMode,filename,rows,pageURL:validateDownloadPage(pageURL)};
 if(payload?.tipo!=='pedidosTabela'||payload?.versao!==1)throw Error('Os dados da exportação não foram preparados corretamente.');
 const normalized={...payload,S:normalizeSheets(payload.S)},raw=new TextEncoder().encode(JSON.stringify(normalized));
 if(raw.length>MAX_XLSX_BYTES)throw Error('O recorte é grande demais. Nenhum arquivo parcial será enviado.');
 const data=b64url(deflateSync(raw,{level:6})),direct=base.pageURL+'#'+new URLSearchParams({v:'2',n:filename,c:'1',j:data}).toString();
 if(direct.length<=MAX_URL_LENGTH)return Object.freeze({...base,transport:'fragment',url:direct});
 const url=base.pageURL+'#'+new URLSearchParams({k:'cola',n:filename,q:String(rows)}).toString();
 if(url.length>MAX_URL_LENGTH)throw Error('Configure um endereço mais curto para a página de download.');
 return Object.freeze({...base,transport:'clipboard',url,clipboardText:XLSX_CLIPBOARD_PREFIX+data});
}
export async function copyPlanPayload(host,plan,event,{clipboard=globalThis.navigator?.clipboard,isCurrent}={}){
 needClick(event);if(plan?.transport!=='clipboard'||!plan.clipboardText?.startsWith(XLSX_CLIPBOARD_PREFIX))throw Error('Os dados completos não foram preparados corretamente.');
 await assertExportPermissions(host,EXPORT_MODES.production,plan.pageURL);checkCurrent(isCurrent);
 if(typeof clipboard?.writeText!=='function')throw Error('A cópia não está disponível neste ambiente.');
 try{await clipboard.writeText(plan.clipboardText);}catch{throw Error('O navegador não permitiu copiar. Clique novamente em Copiar dados.');}
 copiedPlans.add(plan);return {copied:true,rows:plan.rows};
}
export async function launchDownloadPlan(host,plan,event,{isCurrent}={}){
 needClick(event);if(plan?.exportMode!==EXPORT_MODES.production||!plan.url||!plan.url.startsWith(validateDownloadPage(plan.pageURL)+'#')||plan.url.length>MAX_URL_LENGTH)throw Error('A página não está configurada para esta exportação.');
 if(plan.transport==='clipboard'&&!copiedPlans.has(plan))throw Error('Copie os dados antes de abrir a página.');
 await assertExportPermissions(host,EXPORT_MODES.production,plan.pageURL);checkCurrent(isCurrent);
 if(typeof host.launchUrl!=='function')throw Error('O Power BI não oferece abertura da página neste ambiente.');
 host.launchUrl(plan.url);return {opened:true,transport:plan.transport};
}
