import {Visual} from './visual.mjs';
const plugin={name:'novaformaPedidosHTMLA41E65D7C9B64E03A822510202600101',displayName:'Novaforma · Pedidos HTML',class:'Visual',apiVersion:'5.11.0',custom:true,create:options=>new Visual(options)};
if(window.powerbi){window.powerbi.visuals??={};window.powerbi.visuals.plugins??={};window.powerbi.visuals.plugins[plugin.name]=plugin;}
export default plugin;
