import {setMarkup} from './dom.mjs';
export const esc=v=>String(v??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
export const basic=(table,column,values)=>({$schema:'http://powerbi.com/product/schema#basic',filterType:1,target:{table,column},operator:'In',values});
export function dateFilter(field,start,end){return {$schema:'http://powerbi.com/product/schema#advanced',filterType:0,target:{table:field.table,column:field.column},logicalOperator:'And',conditions:[...(start?[{operator:'GreaterThanOrEqual',value:start+'T00:00:00'}]:[]),...(end?[{operator:'LessThanOrEqual',value:end+'T23:59:59'}]:[])]};}
// A business control can address independent fact columns. Keep one physical
// JSON filter per target; the caller submits the complete array atomically.
export function fieldTargets(field){
 const targets=[field,...(field?.targets||[])],seen=new Set();
 return targets.filter(t=>{if(!t?.table||!t?.column)return false;const key=JSON.stringify([t.table,t.column]);if(seen.has(key))return false;seen.add(key);return true;}).map(({table,column})=>({table,column}));
}
export function targetMatches(filter,field){return fieldTargets(field).some(t=>filter?.target?.table===t.table&&filter?.target?.column===t.column);}
export function filtersForField(field,filter){return filter?fieldTargets(field).map(target=>({...filter,target,...(filter.values?{values:filter.values.slice()}:{}),...(filter.conditions?{conditions:filter.conditions.map(c=>({...c}))}:{})})):[];}
// DataViewObjects contains evaluated property values. Hosts may expose a JSON
// filter/array or the persisted Version2 semantic filter for a selfFilter.
export function selfFilters(value){
 if(value==null)return [];
 if(Array.isArray(value))return value.flatMap(selfFilters);
 if(value.filter!==undefined)return selfFilters(value.filter);
 if(value.target)return [value];
 if(Array.isArray(value.whereItems))return selfFilters(internalSQ(value));
 if(value.Version!==2||!Array.isArray(value.Where))throw Error('O estado de filtros recebido do Power BI não foi reconhecido.');
 const aliases=new Map((value.From||[]).map(x=>[x.Name,x.Entity]));
 const column=x=>{const c=x?.Column;if(!c)throw Error('Campo do filtro salvo não reconhecido.');return {table:aliases.get(c.Expression?.SourceRef?.Source)||c.Expression?.SourceRef?.Entity,column:c.Property};};
 const literal=x=>{const v=x?.Literal?.Value;if(typeof v!=='string')throw Error('Valor do filtro salvo não reconhecido.');if(v==='null')return null;if(v==='true'||v==='false')return v==='true';if(v.startsWith("datetime'"))return v.slice(9,-1);if(v.startsWith("'"))return v.slice(1,-1).replaceAll("''","'");const n=Number(v.replace(/[LDM]$/,''));if(!Number.isFinite(n))throw Error('Valor do filtro salvo não reconhecido.');return n;};
 const read=c=>{
  if(c.And)return [...read(c.And.Left),...read(c.And.Right)];
  if(c.In){if(c.In.Expressions?.length!==1)throw Error('Filtro salvo de múltiplas colunas não suportado.');const t=column(c.In.Expressions[0]);return [basic(t.table,t.column,c.In.Values.map(v=>literal(v[0])))];}
  if(c.Comparison){const t=column(c.Comparison.Left),op=['Is','GreaterThan','GreaterThanOrEqual','LessThan','LessThanOrEqual','IsNot'][c.Comparison.ComparisonKind];if(!op)throw Error('Comparação do filtro salvo não reconhecida.');return [{$schema:'http://powerbi.com/product/schema#advanced',filterType:0,target:t,logicalOperator:'And',conditions:[{operator:op,value:literal(c.Comparison.Right)}]}];}
  throw Error('Condição do filtro salvo não reconhecida.');
 };
 const result=[];for(const f of value.Where.flatMap(w=>read(w.Condition))){const existing=result.find(x=>targetMatches(x,f.target)&&x.conditions&&f.conditions);if(existing)existing.conditions.push(...f.conditions);else result.push(f);}return result;
}
// Desktop evaluated StructuralObjectValue, verified against the captured SELF
// fixture. Convert only observed SQ node kinds; reject unknown predicates.
function internalSQ(filter){
 const column=x=>{if((x?._kind??x?.kind)!==2)throw Error('Campo interno SELF não reconhecido.');const entity=x.source?.entity||filter.fromValue?.items?.[x.source?.variable]?.entity;if(!entity||!x.ref)throw Error('Origem interna SELF não reconhecida.');return {Column:{Expression:{SourceRef:{Entity:entity}},Property:x.ref}};};
 const literal=x=>{if((x?._kind??x?.kind)!==17)throw Error('Valor interno SELF não reconhecido.');let encoded=x.typeEncodedValue??x.valueEncoded;
  // Preserve model-local midnight. raw.value is a UTC-converted Date and can
  // differ by timezone; encoded datetime is the original model boundary.
  if(encoded===undefined){if(x.type?.dateTime)throw Error('Data SELF sem valor codificado.');encoded=x.value==null?'null':typeof x.value==='string'?"'"+x.value.replaceAll("'","''")+"'":String(x.value);}
  return {Literal:{Value:encoded}};
 };
 const condition=x=>{switch(x?._kind??x?.kind){case 8:return {And:{Left:condition(x.left),Right:condition(x.right)}};case 10:return {In:{Expressions:x.args.map(column),Values:x.values.map(row=>row.map(literal))}};case 13:return {Comparison:{ComparisonKind:x.comparison,Left:column(x.left),Right:literal(x.right)}};default:throw Error('Condição interna SELF não reconhecida.');}};
 return {Version:2,From:[],Where:filter.whereItems.map(x=>({Condition:condition(x.condition)}))};
}
export function selections(filters,field){const f=(filters||[]).find(f=>targetMatches(f,field));return f?.values||[];}
export function dateSelection(filters,field){
 const conditions=(filters||[]).filter(f=>targetMatches(f,field)).flatMap(f=>f.conditions||[]);
 const lower=conditions.find(c=>c.operator==='GreaterThanOrEqual'),upper=conditions.find(c=>['LessThanOrEqual','LessThan'].includes(c.operator));
 let end=String(upper?.value||'').slice(0,10);
 // An exclusive midnight boundary denotes the previous calendar day. UTC
 // arithmetic avoids local timezone/DST shifts in the date-only controls.
 if(upper?.operator==='LessThan'&&end&&/T00:00:00(?:\.0+)?(?:Z)?$/.test(String(upper.value))){const d=new Date(end+'T00:00:00Z');d.setUTCDate(d.getUTCDate()-1);end=d.toISOString().slice(0,10);}
 return {start:String(lower?.value||'').slice(0,10),end};
}
export function extractRows(body,headers){const t=document.createElement('table');const tb=document.createElement('tbody');t.append(tb);setMarkup(tb,body||'');const rows=Array.from(tb.rows).map(r=>Array.from(r.cells).map(c=>c.textContent??''));if(rows.some(r=>r.length!==headers.length))throw Error('A quantidade de colunas recebida não corresponde ao cabeçalho. Exportação interrompida.');return rows;}
// Quote all fields so identifiers (leading zeroes) and semicolons remain intact.
// Spreadsheet formula injection is prevented without changing displayed values.
export function csvCell(value){let s=String(value??'');if(/^[\t\r\n]*[=+@]/.test(s)||/^-\D/.test(s))s="'"+s;return '"'+s.replace(/"/g,'""')+'"';}
export const csvLine=row=>row.map(csvCell).join(';')+'\r\n';
export function normalized(v){return String(v??'').normalize('NFD').replace(/[\u0300-\u036f]/g,'').toLocaleLowerCase('pt-BR');}
export function validateConfig(c){if(!c||!['Vendido','Em Aberto','Bloqueado'].includes(c.origin)||!['Pedidos','Materiais'].includes(c.view))throw Error('Configuração de origem/visão inválida.');if(!Number.isInteger(c.page)||!Number.isInteger(c.pages)||c.page<1||c.pages<1||c.page>c.pages)throw Error('Paginação inválida no modelo.');if(!Number.isInteger(c.count)||c.count<0)throw Error('Contagem de linhas inválida.');if(!Array.isArray(c.headers)||!c.headers.length||c.headers.length!==c.widths?.length)throw Error('Cabeçalhos e larguras inconsistentes.');if(c.fields?.length>40)throw Error('O visual suporta até 40 campos de filtro.');return c;}
