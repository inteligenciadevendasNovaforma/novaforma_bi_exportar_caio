// HTML table/select fragments require their parsing context. A bare DOMParser
// body discards tr/td/option structures and would silently lose exported rows.
export function setMarkup(target,markup=''){
 const wrappers={TABLE:['<table>','</table>','table'],TBODY:['<table><tbody>','</tbody></table>','tbody'],THEAD:['<table><thead>','</thead></table>','thead'],TFOOT:['<table><tfoot>','</tfoot></table>','tfoot'],TR:['<table><tbody><tr>','</tr></tbody></table>','tr'],SELECT:['<select>','</select>','select'],OPTGROUP:['<select><optgroup>','</optgroup></select>','optgroup']};
 const [before,after,selector]=wrappers[target.tagName]||['','','body'];
 const parsed=new DOMParser().parseFromString('<!doctype html><html><body>'+before+String(markup??'')+after+'</body></html>','text/html');
 const source=selector==='body'?parsed.body:parsed.querySelector(selector);
 target.replaceChildren(...Array.from(source?.childNodes||[],node=>target.ownerDocument.importNode(node,true)));
}
