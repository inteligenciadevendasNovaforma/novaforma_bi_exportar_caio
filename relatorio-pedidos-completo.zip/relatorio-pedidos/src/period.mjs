import {dateSelection,fieldTargets,targetMatches} from './core.mjs';

const dateBR=value=>{
 const iso=String(value??'').slice(0,10);
 return /^\d{4}-\d{2}-\d{2}$/.test(iso)?iso.slice(8,10)+'/'+iso.slice(5,7)+'/'+iso.slice(0,4):'';
};
const interval=(start,end)=>start&&end?(start===end?dateBR(start):dateBR(start)+'–'+dateBR(end)):start?'desde '+dateBR(start):end?'até '+dateBR(end):'';
function calendarText(period){
 if(period.active===false)return 'sem restrição de data';
 const suffix=period.active===true&&period.includesBlank===true?' (inclui sem data)':'';
 if(Number(period.days)===0&&period.days!==null&&period.days!==undefined)return 'sem datas na seleção'+suffix;
 const range=interval(period.start,period.end);
 if(period.contiguous===false&&range)return `${period.days??''} dias selecionados (${range})`.trim()+suffix;
 return (range||'datas selecionadas')+suffix;
}
function appPeriods(config,filters){
 const field=(config.fields||[]).find(f=>f.type==='date'&&(f.key==='field13'||f.label==='Data APP'||fieldTargets(f).some(t=>t.column==='Data APP')));
 if(!field)return [{key:'app',label:'Data APP',text:'sem restrição de data'}];
 const groups=fieldTargets(field).map(target=>{
  const selected=(filters||[]).filter(f=>targetMatches(f,target));
  const {start,end}=dateSelection(selected,target);
  return {target,selected,start,end,text:selected.length?(interval(start,end)||'datas selecionadas'):'sem restrição de data'};
 });
 if(!groups.some(g=>g.selected.length))return [{key:'app',label:'Data APP',text:'sem restrição de data'}];
 if(groups.every(g=>g.text===groups[0].text))return [{key:'app',label:'Data APP',text:groups[0].text}];
 // A restored external state may constrain only one fact or different periods.
 // Show the discrepancy rather than silently describing both with one range.
 return [{key:'app',label:'Data APP',text:groups.map(g=>(g.target.table==='f_Faturamento'?'faturamento':g.target.table==='f_Carteira_2'?'carteira':g.target.table)+': '+g.text).join('; ')}];
}
export function analysisPeriodText(config,appliedFilters=[]){
 const periods=Array.isArray(config.analysisPeriods)?config.analysisPeriods:Array.isArray(config.analysisDates)?config.analysisDates:[];
 const calendar=(key,label)=>({key,label,text:calendarText(periods.find(p=>p.key===key)||{active:false})});
 const parts=[calendar('pedido','Data Entrada'),...appPeriods(config,appliedFilters),calendar('faturamento','Data Faturamento')];
 return 'Período aplicado — '+parts.map(p=>p.label+': '+p.text).join(' · ');
}
